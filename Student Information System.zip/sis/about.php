<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><marquee>Welcome to Student Information System Portal</marquee></title>
<style type="text/css">
<!--
.heading {
	color: #F90;
	font-family: "Comic Sans MS", cursive;
}
.options {
	font-family: "Comic Sans MS", cursive;
	font-size: 16px;
	font-style: oblique;
	color: #F93;
}
-->
</style>
</head>

<body background="admin/images/123.jpg">

<br />
<br />
<br />
<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
    <td><p align="center"><img src="admin/images/cooltext458256871.png" width="170" height="83" alt="About" /></p>
      <table align="center" width="759" border="0">
        <tr>
          <td width="160" height="287"><img src="admin/images/789.jpg" width="160" height="200" /></td>
          <td valign="top" width="589"><ul>
            <li><strong>Project Information</strong>:</li>
            <ul>
              <li>This is a simple <strong>Student Information System</strong> where the user can view, store, modify and delete a student's information. Developed by <strong>Imaginary</strong> as a semester assignment-project <strong>PHP </strong>&amp; <strong>MySQL.</strong></li>
            </ul><br />
            <li><strong>Student Information:</strong></li>
            <ul>
              <li><strong>Name: </strong><a target="_blank" href="http://www.google.co.in">Imaginary</a></li>
              <li><strong>Homepage : </strong><a href="http://www.google.co.in" target="_blank" >www.google.co.in</a></li>
              <!--<li><strong>Roll No : </strong></li>-->
              <li><strong>Program: </strong>BTECH-IT</li>
              <li><strong>Session: </strong>2012-16</li>
              <li><strong>Department: </strong>Information Technology</li>
              <li><strong>Institute: </strong><a target="_blank" href="http://www.nehu.ac.in/">School Of Technology</a>, <a href="http://www.nehu.ac.in" target="_blank" >North Eastern Hill University, Shillong </a>, <a href="http://www.nehu.ac.in" target="_blank">Shillong</a></li>
              <li><strong>Course: </strong>Web Technology</li>
            </ul>
          </ul></td>
        </tr>
      </table>
<table width="70%" align="center">
<tr><td>
</td></tr></table>
    <p align="left">&nbsp;</p></td>
  </tr>
</table>
<h1 align="center" class="heading">&nbsp;</h1>
</body>
</html>
